#ifndef __INT_W25Q32_H__
#define __INT_W25Q32_H__

#include "Driver_SPI1.h"


void Int_W25Q32_Init(void);

void Int_W25Q32_ReadID(uint8_t *manufacture_id, uint16_t *device_id);

void Int_W25Q32_WriteEnalbe(void);

void Int_W25Q32_WriteDisable(void);

void Int_W25Q32_WaitToFree(void);

void Int_W25Q32_EraseSector(uint8_t block, uint8_t sector);

void Int_W25Q32_WritePage(uint8_t block, uint8_t sector_page, uint8_t in_page, uint8_t *data, uint16_t len);

void Int_W25Q32_Read(uint8_t block, uint8_t sector_page, uint8_t in_page, uint8_t *buffer, uint16_t len);

void Int_W25Q32_WriteSpanPage(uint32_t address, uint8_t *data, uint16_t len);

#endif

