#include "Int_ADS1115.h"

/**
 * @brief 初始化ADS1115
 * 
 */
void Int_ADS1115_Init(void)
{
    /* 1. 初始化I2C */
    MX_I2C2_Init();

    /* 2. 配置ADS1115 */
    Int_ADS1115_Config();
}

/**
 * @brief 配置寄存器的值
 * 
 */
void Int_ADS1115_Config(void)
{
    uint16_t conf = 0x8583;

    /* 1. 配置模拟信号通道为0通道 */
    conf &= ~ADS1115_REG_CONFIG_MUX_MASK;
    conf |= ADS1115_REG_CONFIG_MUX_SINGLE_0;

    /* 2. 配置增益: 满量程范围 */;
    conf &= ~ADS1115_REG_CONFIG_PGA_MASK;
    conf |= ADS1115_REG_CONFIG_PGA_4_096V;

    /* 3. 配置连续转换  对应的为置0*/;
    conf &= ~ADS1115_REG_CONFIG_MODE_MASK;
    conf |= ADS1115_REG_CONFIG_MODE_CONTIN;

    /* 配置写出 */
    uint8_t data[3] = {ADS1115_REG_POINTER_CONFIG,(conf >> 8)&0xff,conf & 0xff};
    HAL_I2C_Master_Transmit(&hi2c2,ADS1115_ADDRESS_W,data,3,HAL_MAX_DELAY);
}



/**
 * @brief 读取ADS1115中的电压值
 * 
 * @return double 电压值
 */
double Int_ADS1115_ReadVoltage(void)
{
    uint8_t reg_add = ADS1115_REG_POINTER_CONVERT;
    HAL_I2C_Master_Transmit(&hi2c2,ADS1115_ADDRESS_W,&reg_add,1,HAL_MAX_DELAY);

    uint8_t data[2]={0};
    HAL_I2C_Master_Receive(&hi2c2,ADS1115_ADDRESS_R,data,2,HAL_MAX_DELAY);

    uint32_t tmp = 0;
    tmp |= data[0] << 8;
    tmp |= data[1];

    return tmp * 4.096 / 32767;
}
