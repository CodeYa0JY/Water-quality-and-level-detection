#include "Int_TM7711.h"

void Delay_us(uint32_t us)
{

    uint32_t Delay = us * 72000 / 9 / 1000; /* 72M时钟频率，9是PLL倍频 */
    do
    {
        __NOP(); /* 空指令（NOP）来占用 CPU 时间 */
    } while(Delay--);
}

/**
 * @brief 初始化TM7711
 *
 */
void Int_TM7711_Init(void)
{
    Driver_GPIO_TM7711_Init();
}

/**
 * @brief 获取TM7711输出的值
 *
 * @return uint32_t
 */
uint32_t Int_TM7711_ReadValue(void)
{
    uint32_t data=0;
    // T1
    SCK_LOW;
    while (OUT_READ);
    Delay_us(5);
    // 等待DOUT拉低,然后开始数据传输
    for(uint8_t i = 0; i < 24; i++)
    {
        SCK_HIGH;
        Delay_us(5);
        SCK_LOW;
        /* 开始读取数据 */
        data <<= 1;
        if(OUT_READ)
        {
            data |= 1;
        }
        Delay_us(5);
    }

    SCK_HIGH;
    Delay_us(5);
    SCK_LOW;
    Delay_us(5);
    return data ^ 0x800000;
}
