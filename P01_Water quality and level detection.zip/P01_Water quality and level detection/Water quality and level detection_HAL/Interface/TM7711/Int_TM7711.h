#ifndef __INT_TM7711_H__
#define __INT_TM7711_H__

#include "Driver_GPIO.h"

#define SCK_LOW HAL_GPIO_WritePin(TM7711_SCK_GPIO_Port,TM7711_SCK_Pin,GPIO_PIN_RESET)
#define SCK_HIGH HAL_GPIO_WritePin(TM7711_SCK_GPIO_Port,TM7711_SCK_Pin,GPIO_PIN_SET)
#define OUT_READ HAL_GPIO_ReadPin(TM7711_OUT_GPIO_Port,TM7711_OUT_Pin)

void Delay_us(uint32_t us);

void Int_TM7711_Init(void);

uint32_t Int_TM7711_ReadValue(void);

#endif
