#include "Driver_I2C2.h"

/**
 * @brief 初始化I2C
 *
 */
void Driver_I2C2_Init(void)
{
    // 1.开启时钟
    // 1.1打开I2C2时钟
    RCC->APB1ENR |= RCC_APB1ENR_I2C2EN;
    // 1.2打开GPIOB时钟
    RCC->APB2ENR |= RCC_APB2ENR_IOPBEN;

    // 2.配置PB10(SCL)、PB11(SDA)为复用开漏输出模式(MODE:11 CNF:11)
    GPIOB->CRH |= (GPIO_CRH_MODE10 | GPIO_CRH_MODE11 | GPIO_CRH_CNF10 | GPIO_CRH_CNF11);

    // 3.设置I2C2
    // 3.1配置引脚复用为I2C2
    I2C2->CR1 &= ~I2C_CR1_SMBUS;
    // 3.2配置I2C2时钟:36Mhz
    I2C2->CR2 |= 36;
    // 3.3配置I2C2主模式选项(F/S: 标准模式的I2C(0) 快速模式的I2C(1))
    I2C2->CCR &= ~I2C_CCR_FS;
    // 3.4配置I2C2的通信速率为100Kbit/s
    I2C2->CCR |= 180;
    // 3.5配置I2C2在标准/快速模式下的时钟最大上升时间（主模式）
    // 在标准模式下最大上升时间为1000ns(手册规定)
    // 时钟周期 = 1/时钟频率
    // TRISE[5:0] = 最大上升时间/时钟周期 + 1
    I2C2->TRISE |= 37;
    // 3.6打开I2C2使能
    I2C2->CR1 |= I2C_CR1_PE;
}

/**
 * @brief 设置起始条件产生
 *
 */
uint8_t Driver_I2C2_Start(void)
{
    // 设置起始条件产生
    I2C2->CR1 |= I2C_CR1_START;
    // 等待产生起始信号(SB：未发送起始条件(0) 起始条件已发送(1))
    uint16_t timeout = 0xffff;
    while (((I2C2->SR1 & I2C_SR1_SB) == 0) && timeout)
    {
        timeout--;
    }
    return timeout ? OK : ERROR;
}

/**
 * @brief 设置停止条件产生
 *
 */
void Driver_I2C2_Stop(void)
{
    // 设置停止条件产生
    I2C2->CR1 |= I2C_CR1_STOP;
}

/**
 * @brief 设置产生ACK应答信号
 *
 */
void Driver_I2C2_Ack(void)
{
    I2C2->CR1 |= I2C_CR1_ACK;
}

/**
 * @brief 设置不产生ACK应答信号(产生NACK信号)
 *
 */
void Driver_I2C2_NAck(void)
{
    I2C2->CR1 &= ~I2C_CR1_ACK;
}

/**
 * @brief 发送设备地址
 *
 * @param address 设备地址
 * @return uint8_t 返回发送状态(OK为发送成功，ERROR为发送失败)
 */
uint8_t Driver_I2C2_SendAddr(uint8_t address)
{
    // 1.将设备地址写入数据寄存器(由于发送完起始信号后就是发送设备地址，之前并未发送过数据，因此不需要先判断TxE)
    I2C2->DR = address;
    // 2.等待设备地址发送完成
    uint16_t timeout = 0xffff;
    while(((I2C2->SR1 & I2C_SR1_ADDR) == 0)&&timeout)
    {
        timeout--;
    }

    //地址发送成功后需要先读取SR1，再读取SR2寄存器，清除ADDR标志
    I2C2->SR2;

    return timeout ? OK : ERROR;
}

/**
 * @brief 写一个字节
 *
 * @param data
 * @return uint8_t 返回发送状态(OK为发送成功，ERROR为发送失败)
 */
uint8_t Driver_I2C2_WriteByte(uint8_t data)
{
    // 判断发送寄存器是否为空，若非空（TXE==0）则等待一段时间
    uint16_t timeout = 0xffff;
    while (((I2C2->SR1 & I2C_SR1_TXE) == 0) && timeout)
    {
        timeout--;
    }

    // 发送数据
    I2C2->DR = data;

    // 等待数据发送完成
    timeout = 0xffff;
    while (((I2C2->SR1 & I2C_SR1_BTF) == 0) && timeout)
    {
        timeout--;
    }

    return timeout ? OK : ERROR;
}

/**
 * @brief 读一个字节
 *
 * @return uint8_t 返回读取的字节(ERROR代表读取失败)
 */
uint8_t Driver_I2C2_ReadByte(void)
{
    // 判断接收数据寄存器是否非空，若空（RXNE==0）表示未收到数据，则等待一段时间
    uint16_t timeout = 0xffff;
    while (((I2C2->SR1 & I2C_SR1_RXNE) == 0) && timeout)
    {
        timeout--;
    }

    return timeout ? I2C2->DR : ERROR;
}
