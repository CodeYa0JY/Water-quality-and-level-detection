#ifndef __DRIVER_USART1_H__
#define __DRIVER_USART1_H__

#include <stm32f103xe.h>
#include <stdio.h>

void Driver_USART1_Init(void);

void Driver_USART1_SendChar(char c);

void Driver_USART1_SendString(char *str, uint8_t len);

#endif

