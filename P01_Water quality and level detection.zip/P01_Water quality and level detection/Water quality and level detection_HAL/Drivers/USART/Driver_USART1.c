#include "Driver_USART1.h"

#define MAX_ARR_SIZE 100

// 用于接收和发送的字符数组
char buff[MAX_ARR_SIZE] = {0};
// 用于保存接收到的字符串长度
uint8_t len = 0;
// 标志字符串是否可以发送字符串，1表示字符串接收完毕，可以发送该字符串了
uint8_t can_send = 0;

uint8_t index = 0;

/**
 * @brief 初始化USART1串口
 *
 */
void Driver_USART1_Init(void)
{
    // 1.1打开USART1时钟
    RCC->APB2ENR |= RCC_APB2ENR_USART1EN;
    // 1.2打开GPIOA(TX：PA9、RX：PA10)时钟
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN;

    // 2.配置GPIOA模式(PA9：推挽输出 MODE:11 CNF:10   PA10：浮空输入 MODE:00 CNF:01)
    GPIOA->CRH |= GPIO_CRH_MODE9;
    GPIOA->CRH |= GPIO_CRH_CNF9_1;
    GPIOA->CRH &= ~GPIO_CRH_CNF9_0;

    GPIOA->CRH &= ~GPIO_CRH_MODE10;
    GPIOA->CRH &= ~GPIO_CRH_CNF10_1;
    GPIOA->CRH |= GPIO_CRH_CNF10_0;

    // 3.配置波特率
    USART1->BRR = 0x271;

    // 4.使能USART1
    USART1->CR1 |= (USART_CR1_UE | USART_CR1_TE | USART_CR1_RE);

    // 5.打开中断使能
    USART1->CR1 |= USART_CR1_RXNEIE;
    USART1->CR1 |= USART_CR1_IDLEIE;

    // USART1->CR1 |= USART_CR1_TXEIE;
    // USART1->CR1 |= USART_CR1_TCIE;

    // 设置NVIC
    NVIC_SetPriorityGrouping(3);
    NVIC_SetPriority(USART1_IRQn, 2);
    NVIC_EnableIRQ(USART1_IRQn);
}

/**
 * @brief 发送一个字节
 *
 * @param c 要发送的字节
 */
void Driver_USART1_SendChar(char c)
{
    // 轮询查看发送数据寄存器是否为空，若TEX==0则目前不能发送，则循环等待
    while ((USART1->SR & USART_SR_TXE) == 0)
        ;
    // 发送一个字节
    USART1->DR = c;
}

/**
 * @brief 发送一个字符串
 *
 * @param str 要发送的字符串
 */
void Driver_USART1_SendString(char *str, uint8_t len)
{
    uint8_t i;
    for (i = 0; i < len; i++)
    {
        Driver_USART1_SendChar(str[i]);
    }
}

/**
 * @brief USART1中断处理
 *
 */
void USART1_IRQHandler(void)
{

    // 如果是TXE产生的中断，说明发送数据寄存器为空，可以发送下一个字节
    if (USART1->SR & USART_SR_TXE)
    {
        // 字符串还没发完，继续发送下一个字节
        if (index < len)
        {
            USART1->DR = buff[index++];
        }
        // 字符串发送完成，关闭发送数据寄存器空中断
        else
        {
            USART1->CR1 &= ~USART_CR1_TXEIE;
            // 恢复索引和字符数组长度
            index = 0;
            len = 0;
        }
    }

    // 如果是RXE产生的中断，说明接收数据寄存器有数据，可以读取
    if (USART1->SR & USART_SR_RXNE)
    {
        buff[len] = USART1->DR;
        len++;
    }

    // 如果是IDLE产生的中断，说明接收到了空闲帧，代表字符串接收完成
    if (USART1->SR & USART_SR_IDLE)
    {
        /* 清除空闲中断标志位: 先读sr,再读dr.就可以实现清除了 */
        USART1->SR;
        USART1->DR;
        // 数据接收完毕，可以发送该字符串，打开发送数据寄存器空中断
        USART1->CR1 |= USART_CR1_TXEIE;
    }
}

//printf()重定向
int fputc(int ch, FILE *f)
{
    Driver_USART1_SendChar(ch);
    return ch;
}
