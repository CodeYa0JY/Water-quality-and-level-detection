#include "Driver_SPI1.h"

/**
 * @brief 初始化SPI
 * 
 */
void Driver_SPI1_Init(void)
{
    MX_SPI1_Init();
}

/**
 * @brief SPI开始
 * 
 */
void Driver_SPI1_Start(void)
{
    CS_LOW;
}

/**
 * @brief SPI停止
 * 
 */
void Driver_SPI1_Stop(void)
{
    CS_HIGH;
}

/**
 * @brief 交换一个字节数据
 * 
 * @param byte 要发送的字节
 * @return uint8_t 要接收的字节
 */
uint8_t Driver_SPI1_SwapByte(uint8_t byte)
{
    uint8_t rbyte=0;
    HAL_SPI_TransmitReceive(&hspi1,&byte,&rbyte,1,HAL_MAX_DELAY);
    return rbyte;
}
