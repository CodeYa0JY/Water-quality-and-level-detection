#ifndef __DRIVER_SPI1_H__
#define __DRIVER_SPI1_H__

#include "spi.h"

//引脚操作宏定义

//CS:PC13
#define CS_HIGH (GPIOC->ODR |= GPIO_ODR_ODR13)
#define CS_LOW (GPIOC->ODR &= ~GPIO_ODR_ODR13)

void Driver_SPI1_Init(void);

void Driver_SPI1_Start(void);

void Driver_SPI1_Stop(void);

uint8_t Driver_SPI1_SwapByte(uint8_t byte);

#endif
