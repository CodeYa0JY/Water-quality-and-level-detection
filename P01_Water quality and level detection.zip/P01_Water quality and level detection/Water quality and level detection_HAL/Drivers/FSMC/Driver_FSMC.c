#include "Driver_FSMC.h"

void Driver_FSMC_Init(void)
{
    MX_FSMC_Init();
}
