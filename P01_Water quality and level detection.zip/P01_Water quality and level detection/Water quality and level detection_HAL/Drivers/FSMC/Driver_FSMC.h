#ifndef __DRIVER_FSMC_H
#define __DRIVER_FSMC_H

#include "fsmc.h"
void Driver_FSMC_Init(void);

#endif
