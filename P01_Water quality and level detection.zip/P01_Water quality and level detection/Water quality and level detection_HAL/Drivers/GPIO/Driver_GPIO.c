#include "Driver_GPIO.h"

/**
 * @brief 初始化TM7711的GPIO引脚
 * 
 */
void Driver_GPIO_TM7711_Init(void)
{
}

/**
 * @brief 判断按键3是否按下
 * 
 * @return uint8_t 返回1为按下，返回0为未按下
 */
uint8_t Driver_GPIO_IsKey3Pressed(void)
{
    //等待按键按下
   while((HAL_GPIO_ReadPin(KEY3_GPIO_Port,KEY3_Pin))==0);
    //延时消抖
    HAL_Delay(50);
    if (HAL_GPIO_ReadPin(KEY3_GPIO_Port,KEY3_Pin))
    {
        //等待按键松开
        while (HAL_GPIO_ReadPin(KEY3_GPIO_Port,KEY3_Pin));
        return 1;
    }
    return 0;
}
