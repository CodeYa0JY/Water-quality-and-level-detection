#ifndef __DRIVER_GPIO_H__
#define __DRIVER_GPIO_H__

#include "gpio.h"

void Driver_GPIO_TM7711_Init(void);

uint8_t Driver_GPIO_IsKey3Pressed(void);

#endif  
