#ifndef __APP_WATERLEVEL_H__
#define __APP_WATERLEVEL_H__

#include "Int_TM7711.h"
#include "Int_W25Q32.h"
#include "Int_LCD.h"
#include "string.h"
#include "stdlib.h"

void App_WaterLevel_Init(void);

double App_WaterLevle_ReadWaterLevle(void);

#endif
