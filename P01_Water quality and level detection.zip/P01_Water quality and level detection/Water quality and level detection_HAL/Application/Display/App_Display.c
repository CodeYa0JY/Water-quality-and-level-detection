#include "App_Display.h"

/**
 * @description: 启动显示模块
 */
void App_Display_Start(void)
{
    /* 初始化硬件接口层： LCD */
    Int_LCD_Init();

    /* 设置默认背景色 */
    Int_LCD_ClearAll(WHITE);
}

/**
 * @brief 显示LOGO
 * 
 */
void App_Display_ShowLogo(void)
{
    Int_LCD_WriteAtguiguLogo(57, 5);
}

/**
 * @brief 显示Title
 * 
 */
void App_Display_ShowTitle(void)
{
    for(uint8_t i = 0; i < 9; i++)
    {
        Int_LCD_WriteChineseChar(i * 32 + 16, 70, i, BLUE, WHITE);
    }
}

uint8_t d_buff[50];

/**
 * @brief 显示水深
 * 
 * @param wl 水深
 */
void App_Display_ShowWaterLevel(double wl)
{
    memset((char *)d_buff, 0, sizeof(d_buff));
    sprintf((char *)d_buff, "Water level=%.2fcm     ", wl);
    Int_LCD_WriteAsciiString(10, 120, 24, d_buff, RED, WHITE);
}

/**
 * @brief 显示TDS
 * 
 * @param tds TDS
 */
void App_Display_ShowTDS(double tds)
{
    memset((char *)d_buff, 0, sizeof(d_buff));
    sprintf((char *)d_buff, "TDS=%.2fppm     ", tds);
    Int_LCD_WriteAsciiString(10, 150, 24, d_buff, RED, WHITE);
}
