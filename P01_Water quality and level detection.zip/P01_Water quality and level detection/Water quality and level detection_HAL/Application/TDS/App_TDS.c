#include "App_TDS.h"

/**
 * @description: 开启 TDS 监测
 * @return {*}
 */
void App_TDS_Start(void)
{
    Int_ADS1115_Init();
}

/**
 * @description: 获取TDS的值
 * @return {*}
 */
double App_TDS_GetTDS(void)
{
    /* 1. 获取采集到的电压值 */
    double vol = Int_ADS1115_ReadVoltage();

    /* 2. 利用拟合好的公式，计算TDS的值， */
    double vol2 = vol * vol;
    double result = 66.71 * vol2 * vol - 127.93 * vol2 + 428.7 * vol;

    result = result < 5 ? 0 : result;
    return result;
}
