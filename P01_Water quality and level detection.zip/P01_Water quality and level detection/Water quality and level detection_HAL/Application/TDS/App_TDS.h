#ifndef __APP_TDS_H__
#define __APP_TDS_H__

#include "Int_ADS1115.h"

#endif

void App_TDS_Start(void);

double App_TDS_GetTDS(void);
