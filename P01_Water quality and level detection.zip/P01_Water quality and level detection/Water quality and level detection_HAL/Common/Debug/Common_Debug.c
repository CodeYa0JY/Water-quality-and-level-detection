#include "Common_Debug.h"

void Common_Debug_Init(void)
{
    Driver_USART1_Init();
}
