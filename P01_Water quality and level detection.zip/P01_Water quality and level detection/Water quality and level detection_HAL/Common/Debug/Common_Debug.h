#ifndef __COMMON_DEBUG_H__
#define __COMMON_DEBUG_H__

#include "Driver_USART1.h"
#include <stdarg.h>
#include <string.h>

/**
 *  为方便调试
 *  当定义 DEBUG这个宏之后，所有的输出打印语句会正常打印
 *  如果没有定义这个宏，所有的输出打印机都会在预处理时被去掉。
 *  当调试代码时：    #define DEBUG
 *  当Release代码时： //#define DEBUG
 */
#define DEBUG

#ifdef DEBUG

#define debug_init() Common_Debug_Init()
#define FILENAME (strrchr(__FILE__, '\\') ? strrchr(__FILE__, '\\') + 1 : __FILE__)
#define debug_printf(format, ...) printf("[%s:%d]--" format, FILENAME, __LINE__, ##__VA_ARGS__)
#define debug_printfln(format, ...) printf("[%s:%d]--" format "\r\n", FILENAME, __LINE__, ##__VA_ARGS__)

#else

#define debug_init()  
#define debug_printf(format, ...)    
#define debug_printfln(format, ...)   

#endif

void Common_Debug_Init(void);

#endif
