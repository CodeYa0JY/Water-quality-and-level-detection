#include "Int_ADS1115.h"

/**
 * @brief 初始化ADS1115
 * 
 */
void Int_ADS1115_Init(void)
{
    /* 1. 初始化I2C */
    Driver_I2C2_Init();

    /* 2. 配置ADS1115 */
    Int_ADS1115_Config();
}

/**
 * @brief 配置寄存器的值
 * 
 */
void Int_ADS1115_Config(void)
{
    uint16_t conf = 0x8583;

    /* 1. 配置模拟信号通道为0通道 */
    conf &= ~ADS1115_REG_CONFIG_MUX_MASK;
    conf |= ADS1115_REG_CONFIG_MUX_SINGLE_0;

    /* 2. 配置增益: 满量程范围 */;
    conf &= ~ADS1115_REG_CONFIG_PGA_MASK;
    conf |= ADS1115_REG_CONFIG_PGA_4_096V;

    /* 3. 配置连续转换  对应的为置0*/;
    conf &= ~ADS1115_REG_CONFIG_MODE_MASK;
    conf |= ADS1115_REG_CONFIG_MODE_CONTIN;

    /* 配置写出 */
    Driver_I2C2_Start();

    Driver_I2C2_SendAddr(ADS1115_ADDRESS_W);

    Driver_I2C2_WriteByte(ADS1115_REG_POINTER_CONFIG); /* 表示后面要操作配置寄存器 */

    Driver_I2C2_WriteByte(conf >> 8);
    Driver_I2C2_WriteByte(conf & 0xff);

    Driver_I2C2_Stop();
}

/**
 * @brief 读取设置到寄存器中的值
 * 
 * @return uint16_t 设置的值
 */
uint16_t Int_ADS1115_ReadConfig(void)
{
    Driver_I2C2_Start();

    Driver_I2C2_SendAddr(ADS1115_ADDRESS_W);

    Driver_I2C2_WriteByte(ADS1115_REG_POINTER_CONFIG);
    Driver_I2C2_Stop();

    Driver_I2C2_Start();
    Driver_I2C2_SendAddr(ADS1115_ADDRESS_R);

    uint16_t tmp = 0;
    tmp |= (Driver_I2C2_ReadByte() << 8);
    Driver_I2C2_Ack();
    tmp |= Driver_I2C2_ReadByte();
    Driver_I2C2_Ack();
    Driver_I2C2_Stop();

    return tmp;
}

/**
 * @brief 读取ADS1115中的电压值
 * 
 * @return double 电压值
 */
double Int_ADS1115_ReadVoltage(void)
{
    Driver_I2C2_Start();

    Driver_I2C2_SendAddr(ADS1115_ADDRESS_W);

    Driver_I2C2_WriteByte(ADS1115_REG_POINTER_CONVERT);
    Driver_I2C2_Stop();

    Driver_I2C2_Start();
    Driver_I2C2_SendAddr(ADS1115_ADDRESS_R);

    uint16_t tmp = 0;
    tmp |= (Driver_I2C2_ReadByte() << 8);
    Driver_I2C2_Ack();
    tmp |= Driver_I2C2_ReadByte();
    Driver_I2C2_Ack();
    Driver_I2C2_Stop();

    return tmp * 4.096 / 32767;
}
