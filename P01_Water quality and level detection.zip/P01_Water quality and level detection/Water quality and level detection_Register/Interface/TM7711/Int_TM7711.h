#ifndef __INT_TM7711_H__
#define __INT_TM7711_H__

#include "Driver_GPIO.h"

void Int_TM7711_Init(void);

uint32_t Int_TM7711_ReadValue(void);

#endif
