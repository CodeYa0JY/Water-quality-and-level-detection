#include "Int_W25Q32.h"

/**
 * @brief 初始化W25Q32
 *
 */
void Int_W25Q32_Init(void)
{
    Driver_SPI1_Init();
}

/**
 * @brief 读取生产商ID和设备ID
 *
 * @param manufacture_id 生产商ID
 * @param device_id 设备ID
 */
void Int_W25Q32_ReadID(uint8_t *manufacture_id, uint16_t *device_id)
{
    // 0. 开启 SPI 通道，片选生效
    Driver_SPI1_Start();

    // 1. 发送指令
    Driver_SPI1_SwapByte(0x9f);

    // 2. 下一个周期获取发来的第一个字节，制造商ID
    *manufacture_id = Driver_SPI1_SwapByte(0xff);

    // 3. 下两个周期，获取设备ID
    *device_id = 0;
    *device_id |= Driver_SPI1_SwapByte(0xff) << 8;
    *device_id |= Driver_SPI1_SwapByte(0xff) & 0xff;

    Driver_SPI1_Stop();
}

/**
 * @brief 写入使能
 *
 */
void Int_W25Q32_WriteEnalbe(void)
{
    Driver_SPI1_Start();
    Driver_SPI1_SwapByte(0x06);
    Driver_SPI1_Stop();
}

/**
 * @brief 关闭写入使能
 *
 */
void Int_W25Q32_WriteDisable(void)
{
    Driver_SPI1_Start();
    Driver_SPI1_SwapByte(0x04);
    Driver_SPI1_Stop();
}

/**
 * @brief 等待W25Q32直到设备不忙
 *
 */
void Int_W25Q32_WaitToFree(void)
{
    Driver_SPI1_Start();
    Driver_SPI1_SwapByte(0x05);
    // 循环接收状态，直到发来的状态最后一位为0
    while (Driver_SPI1_SwapByte(0xff) & 0x01)
    {
    }
    Driver_SPI1_Stop();
}

/**
 * @brief 擦除Sector
 *
 * @param block
 * @param sector
 */
void Int_W25Q32_EraseSector(uint8_t block, uint8_t sector)
{
    // 先等待为不忙状态
    Int_W25Q32_WaitToFree();

    // 打开写使能
    Int_W25Q32_WriteEnalbe();
    uint32_t Address = block * 0x010000 + sector * 0x001000;

    // 发送擦除指令
    Driver_SPI1_Start();
    Driver_SPI1_SwapByte(0x20);
    // 发送要擦除的地址
    Driver_SPI1_SwapByte((Address >> 16) & 0xff);
    Driver_SPI1_SwapByte((Address >> 8) & 0xff);
    Driver_SPI1_SwapByte((Address >> 0) & 0xff);

    // 关闭SPI和写失能
    Driver_SPI1_Stop();
    Int_W25Q32_WriteDisable();
}

/**
 * @brief 页写
 *
 * @param block 写入的块
 * @param sector_page 写入的扇区_页
 * @param in_page 写入的页内地址
 * @param data 写入的数据
 * @param len 写入数据的长度
 */
void Int_W25Q32_WritePage(uint8_t block, uint8_t sector_page, uint8_t in_page, uint8_t *data, uint16_t len)
{
    // 先等待为不忙状态
    Int_W25Q32_WaitToFree();

    // 打开写使能
    Int_W25Q32_WriteEnalbe();

    // 发送页写指令
    Driver_SPI1_Start();
    Driver_SPI1_SwapByte(0x02);

    // 发送要写的地址
    Driver_SPI1_SwapByte(block);
    Driver_SPI1_SwapByte(sector_page);
    Driver_SPI1_SwapByte(in_page);

    // 写数据
    for (uint16_t i = 0; i < len; i++)
    {
        Driver_SPI1_SwapByte(data[i]);
    }

    // 关闭SPI和写使能
    Driver_SPI1_Stop();
    Int_W25Q32_WriteDisable();
    Delay_us(5);
}

/**
 * @brief 读数据
 *
 * @param block 要读的块
 * @param sector_page 要读的扇区_页
 * @param in_page 要读的页内地址
 * @param data 读出的的数据
 * @param len 要读数据的长度
 */
void Int_W25Q32_Read(uint8_t block, uint8_t sector_page, uint8_t in_page, uint8_t *buffer, uint16_t len)
{
    // 先等待为不忙状态
    Int_W25Q32_WaitToFree();

    Driver_SPI1_Start();
    Driver_SPI1_SwapByte(0x03);
    // 发送地址
    Driver_SPI1_SwapByte(block);
    Driver_SPI1_SwapByte(sector_page);
    Driver_SPI1_SwapByte(in_page);
    // 读取数据
    for (uint16_t i = 0; i < len; i++)
    {
        buffer[i] = Driver_SPI1_SwapByte(0xff);
    }
    Driver_SPI1_Stop();
}

/**
 * @brief 连续写（可跨页 跨扇区 跨块）
 *
 * @param address 写入的起始地址
 * @param data 需要写入的数据
 * @param len 需要写入数据的长度
 */
void Int_W25Q32WriteSpanPage(uint32_t address, uint8_t *data, uint16_t len)
{
    // 解析地址:块地址，扇区_页地址，页内地址(要传输的三个字节)，扇区地址，页地址
    uint8_t block = address >> 16 & 0xff;
    uint8_t sector_page = address >> 8 & 0xff;
    uint8_t in_page = address & 0xff;

    uint8_t sector = address >> 12 & 0xf;
    uint8_t page = address >> 8 & 0xf;

    // 起始页剩余可写字节数
    uint16_t page_remaining = 256 - in_page;
    // 剩余需要写的字节数
    uint16_t remaining_bytes = len;
    // 当还剩下字节需要写时
    while (1)
    {
        // 如果当前页可以写完剩余字节
        if (page_remaining >= remaining_bytes)
        {
            Int_W25Q32_WritePage(block, sector_page, in_page, data, remaining_bytes);
            break;
        }
        // 如果当前页无法写完剩余字节
        else
        {
            Int_W25Q32_WritePage(block, sector_page, in_page, data, page_remaining);

            // 更新剩余需要写的字节数,以及下一次应该从哪里写入
            remaining_bytes -= page_remaining;
            data = data + page_remaining;

            // 下一次要写的页内地址从0开始，下一页剩余可写字节为256
            in_page = 0;
            page_remaining = 256;

            // 如果本次写的扇区_页没超过254，说明下一次写不用跨块
            if (sector_page <= 254)
            {
                // 下一次要写的扇区_页地址
                sector_page++;

                // 判断是否跨了扇区，如果跨扇区则需要先擦除
                page++;
                // 如果页自增超过15，则说明下一次要写到下一个扇区
                if (page >= 16)
                {
                    // 页号置零
                    page = 0;
                    // 扇区自增
                    sector++;
                    // 擦除下一个扇区
                    Int_W25Q32_EraseSector(block, sector);
                }
            }
            // 跨块
            else
            {
                // 更新地址
                block =  block < 255? block++:0;
                sector_page = 0;
                page = 0;
                sector = 0;
                Int_W25Q32_EraseSector(block, sector_page);
            }
        }
    }
}
