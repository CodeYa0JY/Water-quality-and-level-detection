#include "Driver_SPI1.h"

/**
 * @brief 初始化SPI
 * 
 */
void Driver_SPI1_Init(void)
{
    //1.打开SPI和GPIO时钟
    RCC->APB2ENR |= RCC_APB2ENR_SPI1EN;
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN;
    RCC->APB2ENR |= RCC_APB2ENR_IOPCEN;

    //2.设置GPIO引脚工作模式
    //PA5、PA7复用推挽输出模式(MODE=11,CNF=10)
    GPIOA->CRL |= (GPIO_CRL_MODE5|GPIO_CRL_MODE7);

    GPIOA->CRL &= ~(GPIO_CRL_CNF5_0|GPIO_CRL_CNF7_0);
    GPIOA->CRL |= (GPIO_CRL_CNF5_1|GPIO_CRL_CNF7_1);
    //PC13通用推挽输出模式(MODE=11,CNF=00)
    GPIOC->CRH |= GPIO_CRH_MODE13;
    GPIOC->CRH &= ~GPIO_CRH_CNF13;

    //PA6为浮空输入(MODE=00,CNF=01)
    GPIOA->CRL &= ~GPIO_CRL_MODE6;
    GPIOA->CRL |= GPIO_CRL_CNF6_0; 
    GPIOA->CRL &= ~GPIO_CRL_CNF6_1;

    //3.SPI相关配置
    //设置为主模式
    SPI1->CR1 |= SPI_CR1_MSTR;
    //启用软件从设备管理，禁止在主模式下SS输出，从设备暂时不选择(NSS引脚为高时不选择)
    SPI1->CR1 |= SPI_CR1_SSM;
    SPI1->CR2 &= ~SPI_CR2_SSOE;
    SPI1->CR1 |= SPI_CR1_SSI;
    //波特率设置(BR[2:0]=001：fpclk/4)
    SPI1->CR1 &= ~SPI_CR1_BR;
    SPI1->CR1 |= SPI_CR1_BR_0;
    //使用8位数据帧格式
    SPI1->CR1 &= ~SPI_CR1_DFF;
    //先发送MSB
    SPI1->CR1 &= ~SPI_CR1_LSBFIRST;
    //设置SPI为模式0(CPOL=0,CPHA=0)
    SPI1->CR1 &= ~(SPI_CR1_CPOL|SPI_CR1_CPHA);
    //使能SPI
    SPI1->CR1 |= SPI_CR1_SPE;
}

/**
 * @brief SPI开始
 * 
 */
void Driver_SPI1_Start(void)
{
    CS_LOW;
}

/**
 * @brief SPI停止
 * 
 */
void Driver_SPI1_Stop(void)
{
    CS_HIGH;
}

/**
 * @brief 交换一个字节数据
 * 
 * @param byte 要发送的字节
 * @return uint8_t 要接收的字节
 */
uint8_t Driver_SPI1_SwapByte(uint8_t byte)
{
    //发送寄存器非空则循环等待,等到发送寄存器空则发送
    while ((SPI1->SR & SPI_SR_TXE)==0);
    SPI1->DR = byte;  

    //接收寄存器为空则循环等待，等到接收寄存器非空则接收
    while((SPI1->SR & SPI_SR_RXNE)==0);
    return (uint8_t)(SPI1->DR&0xff);
}
