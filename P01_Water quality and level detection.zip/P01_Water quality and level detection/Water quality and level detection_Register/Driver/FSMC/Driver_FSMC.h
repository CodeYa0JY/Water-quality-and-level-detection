#ifndef __DRIVER_FSMC_H
#define __DRIVER_FSMC_H

#include "stm32f10x.h"
void Driver_FSMC_Init(void);

#endif
