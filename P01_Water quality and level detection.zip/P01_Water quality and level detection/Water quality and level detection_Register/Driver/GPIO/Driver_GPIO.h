#ifndef __DRIVER_GPIO_H__
#define __DRIVER_GPIO_H__

#include "stm32f10x.h"
#include "Common_Util.h"

#define SCK_HIGH (GPIOB->ODR |= GPIO_ODR_ODR12)
#define SCK_LOW (GPIOB->ODR &= ~GPIO_ODR_ODR12)
#define OUT_READ (GPIOB->IDR & GPIO_IDR_IDR13)

void Driver_GPIO_TM7711_Init(void);
uint8_t Driver_GPIO_IsKey3Pressed(void);

#endif  
