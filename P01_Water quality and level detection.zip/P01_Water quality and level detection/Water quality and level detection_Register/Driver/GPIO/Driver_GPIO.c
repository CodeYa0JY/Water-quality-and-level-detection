#include "Driver_GPIO.h"

/**
 * @brief 初始化TM7711的GPIO引脚
 * 
 */
void Driver_GPIO_TM7711_Init(void)
{
    //打开GPIOB时钟
    RCC->APB2ENR |= RCC_APB2ENR_IOPBEN;

    //PB12(SCK)为通用推挽输出：MODE=11 CNF=00;PB13(OUT)为浮空输入：MODE=00 CNF=01
    GPIOB->CRH |= GPIO_CRH_MODE12;
    GPIOB->CRH &= ~GPIO_CRH_CNF12;
    GPIOB->CRH &= ~(GPIO_CRH_MODE13|GPIO_CRH_CNF13_1);
    GPIOB->CRH |= GPIO_CRH_CNF13_0;

    //打开GPIOF时钟
    RCC->APB2ENR |= RCC_APB2ENR_IOPFEN;

    //PF10为下拉输入:MODE=00 CNF=10
    GPIOF->CRH &= ~(GPIO_CRH_MODE10|GPIO_CRH_CNF10_0);
    GPIOF->CRH |= GPIO_CRH_CNF10_1;
    GPIOF->ODR &= ~GPIO_ODR_ODR10;
}

/**
 * @brief 判断按键3是否按下
 * 
 * @return uint8_t 返回1为按下，返回0为未按下
 */
uint8_t Driver_GPIO_IsKey3Pressed(void)
{
    //等待按键按下
    while ((GPIOF->IDR & GPIO_IDR_IDR10)==0);
    //延时消抖
    Delay_ms(50);
    if (GPIOF->IDR & GPIO_IDR_IDR10)
    {
        //等待按键松开
        while (GPIOF->IDR & GPIO_IDR_IDR10);
        return 1;
    }
    return 0;
}
