#include "App_WaterLevel.h"

static void App_WaterLevel_Calibration(void);

void App_WaterLevel_Init(void)
{
    // 初始化TM7711模块
    Int_TM7711_Init();

    // 初始化W25Q32模块
    Int_W25Q32_Init();

    // 对水位进行校准
    App_WaterLevel_Calibration();
}

/**
 * @brief 校准水位（通过相应操作获取a、b的值）
 *  通过按键提示用户校准流程
 *  直接用轮询的方式检测按键是否按下，不利用中断。
 *  y=ax+b。   x 表示水位 y 是对应从AD读出来的值
 *  当 x=0    时得y1
 *  当 x=10cm 时得y2
 *  计算出来 a 和 b的值
 *  b=y1
 *  a=(y2-y1)/10
 *  然后 x = (y - b)/a
 */
double a, b;
// 存储a、b
uint8_t buffer[30] = {0};
uint8_t temp[1] = {0};
static void App_WaterLevel_Calibration(void)
{   
    // 先判断Flash内有没有a、b数据
    Int_W25Q32_Read(0x0, 0x0, 0x0, temp, 1);
    // 如果有数据把Flash内a、b的数据取出来
    if (temp[0] > 0 && temp[0] < 255)
    {
        // 将a、b读出放到buffer中
        Int_W25Q32_Read(0, 0, 1, buffer, temp[0]);
        // 解析a、b的值
        a = strtod(strtok((char *)buffer, "#"), NULL);
        b = strtod(strtok(NULL, "#"), NULL);
        // 结束
        return;
    }
    //如果没有数据，需要先校准
    else
    {
        Int_LCD_WriteAsciiString(10, 150, 24, "Start to calibrate water level...", RED, WHITE);
        Int_LCD_WriteAsciiString(10, 200, 24, "1. Don't put into water, then press the key....", RED, WHITE);
        // 等待第一次按下按键
        while (Driver_GPIO_IsKey3Pressed() == 0);
        int32_t y1 = Int_TM7711_ReadValue();

        Int_LCD_WriteAsciiString(10, 200, 24, "2. Put into water 10cm, then press the key....", RED, WHITE);
        // 等待第二次按下按键
        while (Driver_GPIO_IsKey3Pressed() == 0);
        uint32_t y2 = Int_TM7711_ReadValue();
        b = y1;
        a = (y2 - y1) / 10.0;

        // 在屏幕上显示校准完成信息
        Int_LCD_WriteAsciiString(10, 200, 24, "Calibration is done!                           ", RED, WHITE);
        Delay_ms(1000);
        Int_LCD_ClearArea(0,150,320,100,WHITE);
        /*
        把 a和b的值存入到flash中，下次启动就无需校准
        写入格式：第一个字节表示后面存储的字节数
                后面就是存储的具体数据

                比如: 11 123.45#234.69
                    11表示后面一共存储了11个字节的数据。
        */
        sprintf((char *)buffer, "%.2f#%.2f", a, b);
        temp[0] = strlen((char *)buffer);
        /* 擦除扇区 */
        Int_W25Q32_EraseSector(0x00, 0x00);
        /* 写入第一个字节。 从0x00开始写 */
        Int_W25Q32_WritePage(0x00, 0x00, 0x00, temp, 1);
        /* 接着写入a和b的值. 从0x01开始写tmp[0]个字节 */
        Int_W25Q32_WritePage(0x00, 0x00, 0x01, buffer, temp[0]);
    }
}

double App_WaterLevle_ReadWaterLevle(void)
{
    uint32_t y = Int_TM7711_ReadValue();
    return (y - b) / a;
}
