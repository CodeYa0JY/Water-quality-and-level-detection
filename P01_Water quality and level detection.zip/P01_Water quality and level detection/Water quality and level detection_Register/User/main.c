#include "App_Display.h"
#include "App_TDS.h"
#include "App_WaterLevel.h"
#include "Driver_USART1.h"
#include "Common_Debug.h"

int main()
{
    debug_init();

    /* 1. 启动显示模块 */;
    App_Display_Start();
    /* 显示Logo */
    App_Display_ShowLogo();
    /* 显示标题 */
    App_Display_ShowTitle();

    //初始化TDS
    App_TDS_Start();

    //初始化WaterLevel
    App_WaterLevel_Init();
    
    while (1)
    {   
        double wl = App_WaterLevle_ReadWaterLevle();
        App_Display_ShowWaterLevel(wl);
        Delay_ms(10);
        
        double tds = App_TDS_GetTDS();
        App_Display_ShowTDS(tds);
        Delay_ms(1000);

    }
}
